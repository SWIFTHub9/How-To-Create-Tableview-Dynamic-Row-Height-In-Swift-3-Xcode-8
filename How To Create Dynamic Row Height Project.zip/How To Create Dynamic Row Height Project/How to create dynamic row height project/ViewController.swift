//
//  ViewController.swift
//  How to create dynamic row height project
//
//  Created by Abhishek Verma on 20/08/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var Tableview: UITableView!
    
    let data = ["Education has always been part of Apple’s DNA. We believe technology has the power to transform every classroom and engage every student. Our products are designed to expand how teachers teach and students learn with access to powerful apps and engaging content on the devices they love to use. We also know how important security and privacy is to protect the data students create, store, and access throughout the learning experience.","Security and privacy are fundamental to the design of all Apple hardware, software, and services. We take an integrated approach to ensure that every aspect of the experience has security and privacy built in. This approach considers the privacy and security of all users including those within an education setting such as teachers, faculty, staff and students.","We have also created features and services that are designed specifically for education, including Apple School Manager, Managed Apple IDs, and Shared iPad. These capabilities are built with the same integrated approach and with additional consideration for the specific security and privacy needs of students and institutions.","This overview covers how Managed Apple IDs and our related education features and services handle student data and privacy. You can use this overview to communicate to parents about how their students’ data is secured by Apple."]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = Tableview.dequeueReusableCell(withIdentifier: "cell")
        
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        }
        cell?.textLabel?.text =  data[indexPath.row]
        cell?.textLabel?.numberOfLines = 0
        
        return cell!
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        Tableview.estimatedRowHeight = 44
        Tableview.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

